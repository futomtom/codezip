# iOS-UIKit-Question-2
This is the second part of the iOS-UIKit-Question for Kamcord
