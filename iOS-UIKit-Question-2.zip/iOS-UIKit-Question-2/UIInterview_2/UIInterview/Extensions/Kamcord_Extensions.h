//
//  TimJ_Extensions.h
//  Storyboard
//
//  Created by Timothy Johnson on 8/9/15.
//  Copyright (c) 2015 Timothy Johnson. All rights reserved.
//

#ifndef Kamcord_Extensions_h
#define Kamcord_Extensions_h

#import "UIViewController+Kamcord_Storyboards.h"
#import "UIView+Kamcord_Reuse.h"

#endif
