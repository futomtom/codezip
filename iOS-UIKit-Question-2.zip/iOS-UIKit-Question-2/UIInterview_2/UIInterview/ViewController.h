//
//  ViewController.h
//  UIInterview
//
//  Created by Tim Johnson on 10/8/15.
//  Copyright © 2015 Kamcord. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ViewControllerDelegate <NSObject>

- (void)collectionViewCellWasTapped;

@end

@interface ViewController : UIViewController

@property (nonatomic, weak) id<ViewControllerDelegate> delegate;

@end

