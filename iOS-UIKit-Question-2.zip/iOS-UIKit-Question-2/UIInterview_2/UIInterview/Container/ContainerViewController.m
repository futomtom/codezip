//
//  ContainerViewController.m
//  UIInterview
//
//  Created by Tim Johnson on 12/11/15.
//  Copyright © 2015 Kamcord. All rights reserved.
//

#import "ContainerViewController.h"
#import "ViewController.h"
#import "PlayerViewController.h"
#import "DetailsViewController.h"
#import "Utility.h"

static const CGFloat pipMargins = 15.;
static const NSTimeInterval minDuration = 0.15;
static const NSTimeInterval maxDuration = 0.3;

@interface ContainerViewController () <ViewControllerDelegate, PlayerViewControllerDelegate>

@property (nonatomic, strong) ViewController *feedController;
@property (nonatomic, strong) PlayerViewController *playerController;
@property (nonatomic, strong) DetailsViewController *detailsViewController;

@property (nonatomic) CGFloat panBeginX;
@property (nonatomic) CGFloat panBeginY;
@property (nonatomic) BOOL shouldFinish;


@end

@implementation ContainerViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    [self addFeedController];
}

#pragma mark - Setters & Getters

- (ViewController *)feedController
{
    if (!_feedController)
    {
        _feedController = [[ViewController alloc] init];
        _feedController.delegate = self;
    }
    return _feedController;
}

- (PlayerViewController *)playerController
{
    if (!_playerController)
    {
        _playerController = [[PlayerViewController alloc] init];
        _playerController.delegate = self;
    }
    return _playerController;
}

- (DetailsViewController *)detailsViewController
{
    if (!_detailsViewController)
    {
        _detailsViewController = [[DetailsViewController alloc] init];
    }
    return _detailsViewController;
}

#pragma mark - Adding Controllers

- (void)addFeedController
{
    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:self.feedController];
    [navController willMoveToParentViewController:self];
    
    [self addChildViewController:navController];
    
    UIView *view = navController.view;
    view.translatesAutoresizingMaskIntoConstraints = NO;
    
    [self.view addSubview:view];
    
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|"
                                                                      options:0
                                                                      metrics:nil
                                                                        views:NSDictionaryOfVariableBindings(view)]];
    
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|"
                                                                      options:0
                                                                      metrics:nil
                                                                        views:NSDictionaryOfVariableBindings(view)]];
    
    [navController didMoveToParentViewController:self];
}

- (void)addPlayerControllerToView
{
    [self.playerController willMoveToParentViewController:self];
    [self addChildViewController:self.playerController];
    
    CGFloat width = CGRectGetWidth(self.view.frame);
    self.playerController.view.frame = CGRectMake(0,
                                                  CGRectGetMaxY(self.view.frame),
                                                  width,
                                                  [Utility heightWithDesiredRatioForWidth:width]);
    
    [self.view addSubview:self.playerController.view];
    [self.playerController didMoveToParentViewController:self];
    
    [self.detailsViewController willMoveToParentViewController:self];
    [self addChildViewController:self.detailsViewController];
    
    CGFloat maxY = CGRectGetHeight(self.playerController.view.frame);
    self.detailsViewController.view.frame = CGRectMake(0,
                                                       CGRectGetMaxY(self.view.frame),
                                                       width,
                                                       CGRectGetHeight(self.view.frame) - maxY);
    
    [self.view addSubview:self.detailsViewController.view];
    [self.detailsViewController didMoveToParentViewController:self];
    
    [UIView animateWithDuration:0.3 animations:^{

        self.playerController.view.frame = CGRectMake(0,
                                                      0,
                                                      width,
                                                      [Utility heightWithDesiredRatioForWidth:width]);
        
        self.detailsViewController.view.frame = CGRectMake(0,
                                                           maxY,
                                                           width,
                                                           CGRectGetHeight(self.view.frame) - maxY);
        
    }];
}

#pragma mark - ViewControllerDelegate

- (void)collectionViewCellWasTapped
{
    [self addPlayerControllerToView];
}

#pragma mark - PlayerViewControllerDelegate

- (void)dismissButtonTapped
{
    [self  DismissAnimation];
}

-(void)DismissAnimation
{
    self.detailsViewController.view.hidden = true;
    UIView *view = self.playerController.view;
    CGFloat y = [UIScreen mainScreen].bounds.size.height * 0.9 - pipMargins ;
    CGFloat x = [UIScreen mainScreen].bounds.size.width * 0.8 - pipMargins ;
    [UIView animateWithDuration:1.0 animations:^{
        
        view.transform = CGAffineTransformMakeScale(0.2, 0.2);
        CGRect frame = view.frame;
        frame.origin.x = x ;
        frame.origin.y = y ;
        view.frame = frame;
        
    } completion:^(BOOL finished) {
        
    }];
}

-(void)BackAnimation
{
    
    UIView *view = self.playerController.view;
    [UIView animateWithDuration:1.0 animations:^{
        
        view.transform = CGAffineTransformMakeScale(1, 1);
        CGRect frame = view.frame;
        frame.origin.x = 0;
        frame.origin.y = 0 ;        view.frame = frame;
        
    } completion:^(BOOL finished) {
        self.detailsViewController.view.hidden = false;
        
    }];
}

- (void)Paned:(UIPanGestureRecognizer*)recognizer
{

    CGFloat percentThreshold = 0.5;
    CGFloat height  = recognizer.view.superview.frame.size.height;
    CGPoint pt = [recognizer translationInView:recognizer.view.superview];
   
    CGFloat progress = fabs(pt.y/height);
    
    progress = fmin(fmax(progress,0.01), 0.8);
    progress = round(progress * 100) / 100.0;
    NSLog(@"%f", progress);
    
    
    switch (recognizer.state) {
        case UIGestureRecognizerStateBegan:
            _detailsViewController.view.hidden=YES;
            _shouldFinish = false;

            
            break;
        case UIGestureRecognizerStateChanged:
            _playerController.view.center = pt;
            
            _playerController.view.transform = CGAffineTransformMakeScale(1-progress, 1-progress);
            _shouldFinish = (progress > percentThreshold);
           
            break;
        case UIGestureRecognizerStateEnded:
            
            if(_shouldFinish) {
               
                [self  DismissAnimation];
                
            } else{
                [self  BackAnimation];
            }
        default:
            break;
    }
}


#pragma mark - Helpers

- (void)removeViewController:(UIViewController *)controller
{
    [controller willMoveToParentViewController:nil];
    [controller.view removeFromSuperview];
    [controller removeFromParentViewController];
}

- (CGFloat)minWidth
{
    CGFloat minWidth = [self maxWidth] * (4. / 9.);
    
    return minWidth;
}

- (CGFloat)maxWidth
{
    CGFloat maxWidth = CGRectGetWidth(self.view.frame);
    return maxWidth;
}

- (CGFloat)minHeight
{
    CGFloat minHeight = [Utility heightWithDesiredRatioForWidth:[self minWidth]];
    return minHeight;
}

- (CGFloat)maxHeight
{
    CGFloat maxHeight = [Utility heightWithDesiredRatioForWidth:[self maxWidth]];
    return maxHeight;
}

@end
