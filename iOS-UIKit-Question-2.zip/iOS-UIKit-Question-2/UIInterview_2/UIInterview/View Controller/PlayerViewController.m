//
//  PlayerViewController.m
//  UIInterview
//
//  Created by Tim Johnson on 11/13/15.
//  Copyright © 2015 Kamcord. All rights reserved.
//

#import "PlayerViewController.h"

@interface PlayerViewController()

@property (nonatomic, weak) IBOutlet UIImageView *liveTag;
@property (nonatomic, strong) IBOutletCollection(UIView) NSArray *containerViews;
@property (nonatomic, weak) NSTimer *controlsTimer;
@property (nonatomic) BOOL controlsDisplaying;
@property (nonatomic) UIPanGestureRecognizer *panRecognizer;

@end

@implementation PlayerViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.controlsDisplaying = YES;
    self.liveTag.layer.borderColor = [UIColor whiteColor].CGColor;
    self.liveTag.layer.borderWidth = 2.;
    
    _panRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(HandlePan:)];
    
    [self.view addGestureRecognizer:_panRecognizer];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self startControlsTimer];
}

- (IBAction)dismissButtonTapped:(id)sender
{
    [self.delegate dismissButtonTapped];
}

- (IBAction)playerViewTapped:(id)sender
{
    [self displayControls];
}

- (void)HandlePan:(UIPanGestureRecognizer*)recognizer {
    [self.delegate Paned:recognizer];
    
}

- (void)displayControls
{
    NSLog(@"h");
    [self.controlsTimer invalidate];
    [UIView animateWithDuration:0.3
                     animations:^{
                         
                         for (UIView *view in self.containerViews)
                         {
                             view.alpha = self.controlsDisplaying ? 0 : 1;
                         }
                         
                     } completion:^(BOOL finished) {
                         
                         self.controlsDisplaying = !self.controlsDisplaying;
                         if (self.controlsDisplaying)
                         {
                             [self startControlsTimer];
                         }
                     }];
}

- (void)startControlsTimer
{
    NSDate *fireDate = [[NSDate date] dateByAddingTimeInterval:3];
    NSTimer *timer = [[NSTimer alloc] initWithFireDate:fireDate
                                              interval:0
                                                target:self
                                              selector:@selector(displayControls)
                                              userInfo:nil
                                               repeats:NO];
    
    [[NSRunLoop currentRunLoop] addTimer:timer
                                 forMode:NSDefaultRunLoopMode];
    self.controlsTimer = timer;
}

@end
