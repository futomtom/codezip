//
//  DetailsViewController.h
//  UIInterview
//
//  Created by Tim Johnson on 12/11/15.
//  Copyright © 2015 Kamcord. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailsViewController : UIViewController

@end
