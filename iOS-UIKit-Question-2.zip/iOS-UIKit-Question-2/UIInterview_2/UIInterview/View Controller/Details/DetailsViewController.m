//
//  DetailsViewController.m
//  UIInterview
//
//  Created by Tim Johnson on 12/11/15.
//  Copyright © 2015 Kamcord. All rights reserved.
//

#import "DetailsViewController.h"

@interface DetailsViewController ()

@end

@implementation DetailsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
}

@end
