//
//  PlayerViewController.h
//  UIInterview
//
//  Created by Tim Johnson on 11/13/15.
//  Copyright © 2015 Kamcord. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol PlayerViewControllerDelegate <NSObject>

- (void)dismissButtonTapped;
- (void)Paned:(UIPanGestureRecognizer*)recognizer;

@end

@interface PlayerViewController : UIViewController

@property (nonatomic, weak) id<PlayerViewControllerDelegate> delegate;

@end
