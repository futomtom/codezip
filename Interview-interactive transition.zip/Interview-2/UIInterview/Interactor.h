//
//  interactor.h
//  UIInterview
//
//  Created by alexfu on 5/2/16.
//  Copyright © 2016 Kamcord. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Interactor : UIPercentDrivenInteractiveTransition
@property (nonatomic)BOOL  shouldFinish;
@property (nonatomic)BOOL  hasStarted;
@end
