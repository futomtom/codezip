//
//  DismissAnimator.h
//  UIInterview
//
//  Created by alexfu on 5/2/16.
//  Copyright © 2016 Kamcord. All rights reserved.
//

#import <Foundation/Foundation.h>
@import UIKit;

@interface DismissAnimator : NSObject <UIViewControllerAnimatedTransitioning>

@end
