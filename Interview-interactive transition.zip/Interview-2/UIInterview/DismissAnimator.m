//
//  DismissAnimator.m
//  UIInterview
//
//  Created by alexfu on 5/2/16.
//  Copyright © 2016 Kamcord. All rights reserved.
//

#import "DismissAnimator.h"
#import "PlayerViewController.h"

@implementation DismissAnimator

-(NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    
    return 2.0;
}

-(void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    PlayerViewController *fromVC = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIView *FromView = [transitionContext viewForKey:UITransitionContextFromViewKey];
    UIView *ToView = [transitionContext viewForKey:UITransitionContextToViewKey];
    UIView *containerView = [transitionContext containerView];
    [containerView insertSubview:ToView belowSubview:FromView];
    CGFloat y = [UIScreen mainScreen].bounds.size.height * 0.9 - 15 ;
    CGFloat x = [UIScreen mainScreen].bounds.size.width * 0.8 - 15 ;

    [UIView animateWithDuration:2.0 animations:^{
        FromView.transform = CGAffineTransformMakeScale(0.2, 0.2);
        CGRect frame = FromView.frame;
        frame.origin.x = x ;
        frame.origin.y = y ;
        FromView.frame = frame;
        
        
      
    } completion:^(BOOL finished) {
        if ([transitionContext transitionWasCancelled]) {
           
        } else {
            
            [fromVC SmallsizeSetup];
            
        }
        [transitionContext completeTransition:false];
        
    }];
}

@end
