//
//  ViewController.h
//  UIInterview
//
//  Created by Tim Johnson on 10/8/15.
//  Copyright © 2015 Kamcord. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

