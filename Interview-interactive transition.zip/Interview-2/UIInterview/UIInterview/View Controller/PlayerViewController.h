//
//  PlayerViewController.h
//  UIInterview
//
//  Created by Tim Johnson on 11/13/15.
//  Copyright © 2015 Kamcord. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Interactor.h"


@interface PlayerViewController : UIViewController <UIGestureRecognizerDelegate>
@property (weak, nonatomic) IBOutlet UIView *UpToolBar;
@property (weak, nonatomic) IBOutlet UIView *DownToolBar;
@property (nonatomic) Interactor *interactor;

-(void)SmallsizeSetup;


@end
