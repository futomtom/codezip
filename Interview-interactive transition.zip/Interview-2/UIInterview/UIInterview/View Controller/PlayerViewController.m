//
//  PlayerViewController.m
//  UIInterview
//
//  Created by Tim Johnson on 11/13/15.
//  Copyright © 2015 Kamcord. All rights reserved.
//

#import "PlayerViewController.h"




@interface PlayerViewController ()

@property (nonatomic) BOOL scaled;
@property (nonatomic) BOOL shouldDismiss;
@property (weak, nonatomic) IBOutlet UIView *PlayerView;
@property (weak, nonatomic) IBOutlet UIView *infoView;


@property (nonatomic) UIPanGestureRecognizer *panRecognizer;

@end

@implementation PlayerViewController 


-(void)viewDidLoad {
     [super viewDidLoad];
    _UpToolBar.hidden =TRUE;
    _DownToolBar.hidden = TRUE;
    _shouldDismiss = NO;
    // add a tap recognizer
    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc]
                                             initWithTarget:self action:@selector(HandleTap:)];
    [self.view addGestureRecognizer:tapRecognizer];
    
   _panRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(HandlePan:)];
    
    [self.view addGestureRecognizer:_panRecognizer];
    
    
}
- (IBAction)DismissTap:(id)sender {
    
    _infoView.hidden = YES;
    [self dismissViewControllerAnimated:true completion:nil];
    
}

- (void)HandlePan:(UIPanGestureRecognizer*)recognizer
{
    CGFloat percentThreshold = 0.3;
    CGFloat height  = recognizer.view.superview.frame.size.height;
    CGPoint pt = [recognizer translationInView:recognizer.view.superview];
    CGFloat progress = fabs(pt.y/height);
   
    progress = fmin(fmax(progress,0.01), 1);
   
    
    switch (recognizer.state) {
       case UIGestureRecognizerStateBegan:
            _interactor.hasStarted = true;
            _infoView.hidden = true;
            [self dismissViewControllerAnimated:YES completion:nil];
            break;
        case UIGestureRecognizerStateChanged:
            _interactor.shouldFinish = (progress > percentThreshold);
            [_interactor updateInteractiveTransition:progress];
            break;
        case UIGestureRecognizerStateEnded:
            _interactor.hasStarted = false;
            if(_interactor.shouldFinish) {
                [ _interactor finishInteractiveTransition];
                
            } else{
                [_interactor cancelInteractiveTransition];
                _infoView.hidden = false;
            }
        default:
            break;
    }
   
}


- (void)HandleTap:(UITapGestureRecognizer*)recognizer
{
    if (_UpToolBar.hidden == FALSE)
    {
        [self dismissViewControllerAnimated:TRUE completion:nil];
        
        
    }
    
    _UpToolBar.hidden =FALSE;
    _DownToolBar.hidden = FALSE;
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        _UpToolBar.hidden =TRUE;
        _DownToolBar.hidden = TRUE;
    });
    
}

-(void)SmallsizeSetup {
    [self.view removeGestureRecognizer:_panRecognizer];
     _panRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(HandleCompactPan:)];
   
    [self.view addGestureRecognizer:_panRecognizer];
    
}

- (void)HandleCompactPan:(UIPanGestureRecognizer*)recognizer
{
  
    CGFloat height  = recognizer.view.superview.frame.size.height;
    CGPoint pt = [recognizer translationInView:recognizer.view];
    
   
    switch (recognizer.state) {
     
        case UIGestureRecognizerStateChanged:
            //Should check beyond Screen here. 
            _shouldDismiss = YES;
            
            break;
        case UIGestureRecognizerStateEnded:
            if(_shouldDismiss) {
                [ self dismissViewControllerAnimated:false completion:nil];
              
            }
        default:
            break;
    }
    
}



@end
